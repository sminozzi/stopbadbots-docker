<?php

/**
 * @ Author: Bill Minozzi
 * @ Copyright: 2020 www.BillMinozzi.com
 * @ Modified time: 2020-07-02 19:02:32
 * 
 * For details, visit:
 * http://StopBadBots.com
 */
// use function PHPSTORM_META\elementType;
///// ===>>>>  setsebool -P httpd_can_network_connect=1

define('SBB_PORT', '8080');
define('SBB_DEBUG', false);

if (SBB_DEBUG) {
    error_reporting(E_ALL);
    ini_set('display_errors', 1);
    echo 'Port: ' . SBB_PORT;
    echo '<hr>';
}
if (count(debug_backtrace()) < 1)
    die('Include this file on top of your main index.php file. Look our Online guide for details. <br /> http://StopBadBots.com/help4/ ');
define('SBB_DOMAIN', preg_replace('/^www\./', '', strip_tags($_SERVER['SERVER_NAME']))); //example.com
$url = 'http://' . SBB_DOMAIN . ':' . SBB_PORT . '/';
if (!filter_var($url, FILTER_VALIDATE_URL)) {
    echo $url;
    echo '<br />';
    echo ("URL is not valid");
    echo '<br />';
    echo 'Please Check our Online Guide, How install on Docker, Invalid URL';
    echo '<br />';
    echo 'http://StopBadBots.com/help4/';
    die();
}
// Firewall
$sbb_request_uri_array = array('@eval', 'eval\(', 'UNION(.*)SELECT', '\(null\)', 'base64_', '\/localhost', '\%2Flocalhost', '\/pingserver', 'wp-config\.php', '\/config\.', '\/wwwroot', '\/makefile', 'crossdomain\.', 'proc\/self\/environ', 'usr\/bin\/perl', 'var\/lib\/php', 'etc\/passwd', '\/https\:', '\/http\:', '\/ftp\:', '\/file\:', '\/php\:', '\/cgi\/', '\.cgi', '\.cmd', '\.bat', '\.exe', '\.sql', '\.ini', '\.dll', '\.htacc', '\.htpas', '\.pass', '\.asp', '\.jsp', '\.bash', '\/\.git', '\/\.svn', ' ', '\<', '\>', '\/\=', '\.\.\.', '\+\+\+', '@@', '\/&&', '\/Nt\.', '\;Nt\.', '\=Nt\.', '\,Nt\.', '\.exec\(', '\)\.html\(', '\{x\.html\(', '\(function\(', '\.php\([0-9]+\)', '(benchmark|sleep)(\s|%20)*\(', 'indoxploi', 'xrumer');
$sbb_query_string_array = array('@@', '\(0x', '0x3c62723e', '\;\!--\=', '\(\)\}', '\:\;\}\;', '\.\.\/', '127\.0\.0\.1', 'UNION(.*)SELECT', '@eval', 'eval\(', 'base64_', 'localhost', 'loopback', '\%0A', '\%0D', '\%00', '\%2e\%2e', 'allow_url_include', 'auto_prepend_file', 'disable_functions', 'input_file', 'execute', 'file_get_contents', 'mosconfig', 'open_basedir', '(benchmark|sleep)(\s|%20)*\(', 'phpinfo\(', 'shell_exec\(', '\/wwwroot', '\/makefile', 'path\=\.', 'mod\=\.', 'wp-config\.php', '\/config\.', '\$_session', '\$_request', '\$_env', '\$_server', '\$_post', '\$_get', 'indoxploi', 'xrumer');
$sbb_request_uri_string = false;
$sbb_query_string_string = false;
if (isset($_SERVER['REQUEST_URI']) && !empty($_SERVER['REQUEST_URI'])) {
    $sbb_request_uri_string = $_SERVER['REQUEST_URI'];
}
if (isset($_SERVER['QUERY_STRING']) && !empty($_SERVER['QUERY_STRING'])) {
    $sbb_query_string_string = $_SERVER['QUERY_STRING'];
}
if ($sbb_request_uri_string || $sbb_query_string_string) {
    if (
        preg_match('/' . implode('|', $sbb_request_uri_array) . '/i', $sbb_request_uri_string, $matches) ||
        preg_match('/' . implode('|', $sbb_query_string_array) . '/i', $sbb_query_string_string, $matches2)
    ) {
        sbb_response();
        // wp_die("");
    } // Endif match...
} // endif if ($sbb_query_string_string || $user_agent_string)
$ip = sbb_findip();
$ua = sbb_get_ua();
if (isset($_SERVER['HTTP_REFERER']))
    $ref = strip_tags($_SERVER['HTTP_REFERER']);
else
    $ref = '';
// To Test, uncoment one.
//$ref = '007angels.com';
// $ip = '101.4.136.34';
// $ua = 'Acoon';
$sbb_cookie = 'stopbadbots_cookie';
if (isset($_COOKIE[$sbb_cookie])) {
    $sbb_cookie = $_COOKIE[$sbb_cookie];
} else { // No cookie
    $sbb_cookie = '0';
    sbb_include_cookies($ip);
}
if (function_exists('curl_init') === false) {
    $postdata = http_build_query(
        array(
            'ua' => $ua,
            'api' => '1',
            'ref' => $ref,
            'ip' => $ip,
            'cookie' => $sbb_cookie
        )
    );
    $opts = array('http' =>
    array(
        'method'  => 'POST',
        'header'  => 'Content-Type: application/x-www-form-urlencoded',
        'content' => $postdata
    ));
    $context  = stream_context_create($opts);
    try {
        $result = file_get_contents($url, false, $context);
    } catch (Exception $e) {
        echo 'Caught exception (1): ',  $e->getMessage(), "\n";
        return;
    }
    if ($result === false) {
        if (SBB_DEBUG)
            die('Stop Bad Bots Fail to connect with API (1)');
    }
    if ($result == '0')
        sbb_response();
    return;
}
$data =  array(
    'ua' => urlencode($ua),
    'api' => '1',
    'ref' => urlencode($ref),
    'ip' => $ip,
    'cookie' => $sbb_cookie
);
$ch = curl_init($url);
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_VERBOSE, true);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
$agent = 'PHP Curl';
curl_setopt($ch, CURLOPT_USERAGENT, $agent);
curl_setopt($ch, CURLOPT_TIMEOUT, 5);
try {
    $result = curl_exec($ch);
} catch (Exception $e) {
    echo 'Caught exception on Curl: ',  $e->getMessage(), "\n";
    return;
}
if (SBB_DEBUG) {
    //  echo 'Stop Bad Bots Fail to connect with API (2)';
    echo '<hr>';
    echo 'Curl Error Dump: ';
    echo '<hr>';
    var_dump(curl_getinfo($ch));
    echo '<hr>';
    echo 'Curl erro Number: ' . curl_errno($ch);
    echo '<hr>';
    echo 'Curl Error: ' . curl_error($ch);
    echo '<hr>';
    die(var_dump($result));
}
curl_close($ch);
if ($result == '0')
    sbb_response();
return;
// End Code, begin functions
//////////////////////////
function sbb_response()
{
    http_response_code(403);
    header('HTTP/1.1 403 Forbidden');
    header('Status: 403 Forbidden');
    header('Connection: Close');
    exit();
}
function sbb_findip()
{
    $ip = '';
    $headers = array(
        'HTTP_CLIENT_IP', // Bill
        'HTTP_X_REAL_IP', // Bill
        'HTTP_X_FORWARDED', // Bill
        'HTTP_FORWARDED_FOR', // Bill
        'HTTP_FORWARDED', // Bill
        'HTTP_X_CLUSTER_CLIENT_IP', //Bill
        'HTTP_CF_CONNECTING_IP', // CloudFlare
        'HTTP_X_FORWARDED_FOR', // Squid and most other forward and reverse proxies
        'REMOTE_ADDR', // Default source of remote IP
    );
    for ($x = 0; $x < 8; $x++) {
        foreach ($headers as $header) {
            /*
            if(!array_key_exists($header, $_SERVER))
            continue;
             */
            if (!isset($_SERVER[$header])) {
                continue;
            }
            $myheader = trim(strip_tags($_SERVER[$header]));
            if (empty($myheader)) {
                continue;
            }
            $ip = trim(strip_tags($_SERVER[$header]));
            if (empty($ip)) {
                continue;
            }
            if (false !== ($comma_index = strpos(strip_tags($_SERVER[$header]), ','))) {
                $ip = substr($ip, 0, $comma_index);
            }
            // First run through. Only accept an IP not in the reserved or private range.
            if ($ip == '127.0.0.1') {
                $ip = '';
                continue;
            }
            if (0 === $x) {
                $ip = filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_NO_RES_RANGE |
                    FILTER_FLAG_NO_PRIV_RANGE);
            } else {
                $ip = filter_var($ip, FILTER_VALIDATE_IP);
            }
            if (!empty($ip)) {
                break;
            }
        }
        if (!empty($ip)) {
            break;
        }
    }
    if (!empty($ip)) {
        return $ip;
    } else {
        return 'unknow';
    }
}
function sbb_get_ua()
{
    if (!isset($_SERVER['HTTP_USER_AGENT'])) {
        return "mozilla compatible";
    }
    $ua = trim(strip_tags($_SERVER['HTTP_USER_AGENT']));
    return $ua;
}
function sbb_include_cookies($ip)
{
?>
    <script>
        document.cookie = escape('stopbadbots_cookie') + "=" + escape('1') + '' + "; path=/";
    </script>
<?php
    return;
}
?>